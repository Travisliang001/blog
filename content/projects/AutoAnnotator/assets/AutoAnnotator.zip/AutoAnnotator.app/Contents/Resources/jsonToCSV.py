import pandas as pd
import json
    
"""
   The JSON format must be
   {ImageName: String,
   shapes: { label: String,
            points: [] }
   """

class JsonToCSV:
    # A class to transfom JSON file to CSV containing Image boundaries
    def __init__(self,json_file):
        self.json_file=json_file

        # Read The JSON File
        self.json_data= json.load(open(self.json_file))
        self.imageName = self.json_data.get("imageName")
        self.length=len(self.json_data.get('shapes')) # Total number of bounding boxes
        # To obtain the DataFrame containing labels and bounding boxes
        self.dataset=self.get_dataframe()
    def get_dataframe(self):
        bbox=[] # Bounding Boxes
        labels=[] # Labels

        for i in range(self.length):
            labels.append(self.json_data.get("shapes")[i]['label'])
            bbox.append(self.json_data.get("shapes")[i]['bboxCoord'])

        dataset=pd.DataFrame({"image_name":[self.imageName]*self.length,"bbox":bbox,"label":labels})
        return dataset
    
    def save_dataframe(self,path):
        if len(self.dataset) > 0:
            self.dataset.to_csv(path,index=False)
        
