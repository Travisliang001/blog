import numpy as np
import cv2
import json
import warnings
import colorsys
from error_message import *
from jsonToCSV import JsonToCSV
from dataGenerator import DataGenerator
from iou import bb_intersection_over_union

class TemplateMatcher(DataGenerator):

    """ Template Matching """

    def __init__(self,json_file,imagePath):
        super().__init__()

        """
        Params:

        json_file --> JSON file created using labelme.
        image --> Image Array
        """

        self.json_file=json_file.split("://")[-1]
        self.original_image = cv2.imread(imagePath.split("://")[-1],cv2.IMREAD_GRAYSCALE)
        self.height,self.width=self.original_image.shape
        self.scaleFactor=0.3

        # Transforming the JSON to CSV
        json2csv=JsonToCSV(self.json_file)

        # Store the original labelme json file
        self.labelmeData=json2csv.json_data

        # The Image file needs to be transformed to Grayscale.
        self.image=np.asarray(self.resize_image(self.original_image,(int(self.width*self.scaleFactor),int(self.height*self.scaleFactor))),dtype=np.uint8)
        self.image_height,self.image_width=self.image.shape
        
        # Obtaining The dataset
        self.data=json2csv.dataset
        
        # Image Name
        self.imageName=json2csv.imageName

        # To store the height and width of every template boxes
        self.height=dict()
        self.width=dict()
        
        self.json_file_name="/".join(self.json_file.split("/")[:-1])+"/."+self.imageName.split(".")[0]+"_matched.json"


    def match_template(self,threshold,search_space_boundary=0,rotation_min=None,rotation_max=None,flipping=True):
        """ Template Matcher for Any Label """
        #print("TEMPLATE MATCHING STARTED....")
        # Creating a dictionary for storing boxes for all images
        self.all_boxes=dict()

        # A dictionary to store the cross-correlation value
        self.all_box_dict=dict()
        threshold = float(threshold)

        # Get all the labels from the dataset
        self.all_labels = list(self.data['label'].unique())
        #self.data["label"]=self.data['label'].apply(lambda x: x.split(" ")[0])
        
        # If range of rotation is provided or only the rotation
        if not rotation_min and not rotation_max:
            rotation_range=(None,None)
        elif rotation_min and not rotation_max:
            rotation_range=(rotation_min,None)
        else:
            rotation_range=(rotation_min,rotation_max)

        # Template matching for all the labels
        for l in self.all_labels:
            #print(f"TEMPLATE MATCHING FOR LABEL {l}")
            bbox=np.array(self.data[self.data['label']==l]['bbox'].values)
            i=0
            for bb in bbox:
                bb=np.int64(np.ceil(np.array(bb)*self.scaleFactor))
                self.currentBox = bb
                # Correct box coordinate adjustment(if necessary)
                if bb[0][1]>bb[1][1]:
                    bb=[[bb[0][0],bb[1][1]],[bb[1][0],bb[0][1]]]
                if bb[0][0]>bb[1][0]:
                    bb=[[bb[1][0],bb[0][1]],[bb[0][0],bb[1][1]]]

                # The image template that we need to match
                template=self.image[bb[0][1]:bb[1][1],bb[0][0]:bb[1][0]]
                w,h=template.shape[::-1] # Template shape and width
                self.height[l]=h
                self.width[l]=w

                 # All the detected objects for the templates
                val = self.find_all_template(bb,template,l,threshold,search_space_boundary,rotation_range,flipping)
                try:
                    self.all_boxes[l]+=val[0]
                    for key in val[1].keys():
                        self.all_box_dict[l][key]=val[1][key]
                    i+=1
                except:
                    self.all_boxes[l]=val[0]
                    self.all_box_dict[l]=val[1]
                    i+=1
            if i>1:
                self.all_boxes[l],self.all_box_dict[l]=self.non_max_suppression(self.all_boxes[l],self.all_box_dict[l])
            self.all_boxes[l]=[self.create_boxes(i,self.all_box_dict[l]) for i in self.all_boxes[l]]
        
        #print("TEMPLATE MATCHING ENDED")
        
        # Save the boxes in another json file
        self.createJSON()
        #return self.all_boxes[self.all_labels[0]],self.all_box_dict[self.all_labels[0]]
    
    def find_all_template(self,bbox,template,label,threshold=0.6,s=0,rotation_range=(None,None),flipping=False):
        """ Find all the the boxes for the template in image """

        self.w,self.h=template.shape[::-1] # The height and the width of the template

        # The search space is the entire image
        search_space = self.image

        # INITIALIZING VARIABLE TO CREATE AND SELECT BOXES
        boxes=[]
        box_dict=dict() # Contains the similarity value, template shape and the label

        # Get matching objects for the current template
        _,boxes,box_dict=self.match(search_space,label,template,threshold)

        # ROTATION, FLIPPING AND SCALING IS TURNED OFF NOW

        # Get matching objects for the rotated version of the template
        # if if_rotation:
        #     print("ROTATION WAS ENABLED")
        #     for j in rotaion_space:
        #         label_rotated=label+"_rotated_"+str(j)
        #         template_rotated=np.array(self.rotate_image(template,j))
        #         a,b=self.match(search_space,label_rotated,template_rotated)

        # # Get matching objects for the flipped version of the template
#        if flipping:
#            label_flipped=label
#            template_flipped=np.array(self.flip_image(template))
#            _,flippedBoxes,filppedBoxDict=self.match(search_space,label_flipped,template_flipped,threshold)
#            boxes+=flippedBoxes
#            for key in filppedBoxDict:
#                box_dict[key]=filppedBoxDict[key]
#
#            label_mirrored=label
#            template_mirrored=np.array(self.mirror_image(template))
#            _,mirroredBoxes,mirroredBoxDict=self.match(search_space,label_mirrored,template_mirrored,threshold)
#            boxes+=mirroredBoxes
#            for key in mirroredBoxDict:
#                box_dict[key]=mirroredBoxDict[key]

         # Get matching objects for the scaled version of the template
#        for scale in np.linspace(0.5,2,25):
#            h,w=template.shape[::-1]
#            w=int(np.floor(w*scale))
#            h=int(np.floor(h*scale))
#            # Scaling the Template
#            template_scaled=np.array(self.resize_image(template,(w,h)))
#            if h<search_space.shape[0] and w<search_space.shape[1]:
#                _,scaledBoxes,scaledBoxDict=self.match(search_space,label,template_scaled,threshold)
#                boxes+=scaledBoxes
#                for key in scaledBoxDict:
#                    box_dict[key]=scaledBoxDict[key]

        #         if flipping:
        #             template_flipped_scaled=np.array(self.resize_image(template_flipped,(w,h)))
        #             a,b=self.match(search_space,label_flipped,template_flipped_scaled)
        #             template_mirrored_scaled=np.array(self.resize_image(template_mirrored,(w,h)))
        #             a,b=self.match(search_space,label_mirrored,template_mirrored_scaled)
                
        #         if if_rotation:
        #             for j in rotaion_space:
        #                 label_rotated=label+"_rotated_"+str(j)
        #                 template_rotated=np.array(self.rotate_image(template_scaled,j))
        #                 a,b=self.match(search_space,label_rotated,template_rotated)

        #self.clean_box_dict()
        # Perform non max suppression to get the best boxes
        boxes,box_dict=self.non_max_suppression(boxes,box_dict)
        #boxes=[self.create_boxes(i,box_dict) for i in boxes]
        
        #print(f"TEMPLATE MATCHING FINISHED FOR LABEL {label}")
        
        return boxes,box_dict
    
    def match(self,search_space,label,template,threshold=0.25,method=cv2.TM_CCOEFF_NORMED):
        """ Template Matching for Translation, Rotation, Flipping """

        res=cv2.matchTemplate(search_space,template,method=method)
        loc = np.where(res >= threshold)
        loc=(loc[0],loc[1])

        w,h=template.shape[::-1]
        # Collect all the top left corners of the boxes
        # Boxes only for translation matching
        boxes=[]
        box_dict = dict()
        for pt in zip(*loc[::-1]):
            pt=(pt[0],pt[1])
            boxes.append(pt)
            try:
                box_dict[pt].append([res[pt[1]][pt[0]],(w,h),label])
            except:
                box_dict[pt]=[res[pt[1]][pt[0]],(w,h),label]

        #self.boxes+=boxes

        return res,boxes,box_dict
    def clean_box_dict(self):
        """ In box dict the same point can have label,label_flipped and label_rotated boxes. Keep only the max value"""
        all_points=list(self.box_dict.keys())
        flip_exists=[0,True]
        for bx in all_points:
            if len(self.box_dict[bx])>1:
                all_values=[]
                for num,val in enumerate(self.box_dict[bx]):
                    if "flipped" in val[2].split("_")[-1] or "mirrored" in val[2].split("_")[-1]:
                        flip_exists=[num,True]
                    all_values.append(val[0])
                pos=np.argmax(all_values)
                if "rotated" in self.box_dict[bx][pos][2] and flip_exists[-1]:
                    pos=flip_exists[0]
                    break
                self.box_dict[bx]=[self.box_dict[bx][pos]]
        for bx in all_points:
            self.box_dict[bx]=self.box_dict[bx][0]

    
    def create_boxes(self,box,box_dict):
        """ Create four coordinates from the corner point """
        w,h=box_dict[(box[0],box[1])][1]
        return [[box[0],box[1]],[box[0]+w,box[1]+h]]
    
    
    def warning(self):
        warnings.warn("WARNING: Duplicate Label Detected. First Box of the same label will be taken into account.", DuplicateWarning,stacklevel=2)
    
    def check_int(self,value):
        try:
            value=int(value)
        except:
            raise TypeError("Only Integer Values are allowed")



    def non_max_suppression(self,boxes,box_dict):
        
        """ Perform Non-Max Suppression for removing overlapping boxes."""

        new_box=[]
        for i,b in enumerate(boxes):
            b_box=self.create_boxes(b,box_dict)
            update=True
            for j,nb in enumerate(new_box):
                nb_box=self.create_boxes(nb,box_dict)
                if bb_intersection_over_union(nb_box,b_box) > 0.2 and box_dict[b][0]>box_dict[nb][0]:
                    if bb_intersection_over_union(self.currentBox,b_box) < 0.4:
                        new_box[j]=b
                    update=False
                    #del box_dict[nb]
                    break
                elif bb_intersection_over_union(nb_box,b_box) > 0.1:
                    update=False
                    #del box_dict[b]
                    break

            if update and bb_intersection_over_union(self.currentBox,b_box)<0.4:
                new_box.append(b)
        return new_box,box_dict

    def random_color(self,label):
        """ Generate Random colors for bounding box"""

        color=colorsys.hsv_to_rgb(np.random.rand(), 1, np.random.randint(0,200))
        
        return color

    
        
    def createJSON(self):
        """ A class to transform JSON or CSV file to LabelMe JSON format """

        # Since the file is saved, self.save is True
        self.save=True

        # Store all the keys.
        keys=self.labelmeData.keys()

        # Store all the labels from all_boxes
        labels=list(self.all_boxes.keys())

        # Get all the colors
        shapes=self.labelmeData['shapes']

        # # Outline for boxes
        # colors=dict()
        # for i in range(len(labels)):
        #     color=shapes[i]['line_color']
        #     if not color:
        #         color=self.random_color(int(labels[i]))
        #         #color=[int(i) for i in color]
        #         colors[labels[i]]=color
        #     else:
        #         try:
        #             colors[labels[i]]=color
        #         except:
        #             pass
        
        self.labelmeData['shapes']=[]

        # Append all the all boxes.
        for lb in labels:
            # if all the boxes are of flipped category, change it to normal
            for bx in self.all_boxes[lb]:
                # A temporary Dictionary
                temp=dict()
                temp['label']=self.all_box_dict[lb][tuple(bx[0])][2]
                #temp['line_color']=colors[lb]
                #temp['fill_color']=None
                bx=[[int(bx[0][0]/self.scaleFactor),int(bx[0][1]/self.scaleFactor)],[int(bx[1][0]/self.scaleFactor),int(bx[1][1]/self.scaleFactor)]]
                temp['bboxCoord']=bx
                #temp['shape_type']="rectangle"
                self.labelmeData['shapes'].append(temp)
        
        # Store the json file.
        
        with open(self.json_file_name, 'w+') as fp:
            json.dump(self.labelmeData, fp,indent=2)
        #print("JSON FILE SAVED IN ",self.json_file_name)
