def checkIfInstalled(package,installer=""):
    # Checks if a package is installed and if it's not installed, use pip install to install the library
    if installer == "":
        installer = package
    try:
        __import__(package)
    except:
        import subprocess
        subprocess.call([sys.executable, "-m", "pip", "install", installer])

def checkPackage():
    checkIfInstalled("numpy")
    checkIfInstalled("pandas")
    checkIfInstalled("json")
    checkIfInstalled("cv2","opencv-python")
    checkIfInstalled("PIL","pillow")
    checkIfInstalled("colorsys")
